# MAXO Edit — Development Plan

Tagline: Create Beyond Limits.

## Architecture
- App: Expo (React Native) + TypeScript, Android नेटिव ऐप
- Storage: AsyncStorage (प्रोजेक्ट JSON, मोड सेटिंग), ऑटो-सेव
- Video engine (Phase 2-8): FFmpeg ऑफ़लाइन; लाइब्रेरी चुनने से पहले जाँच होगी कि कौन-सी चालू है
- Preview: expo-video / expo-av
- AI (Phase 9): मुफ़्त/ओपन-सोर्स मॉडल, जहाँ क्लाउड चाहिए वहाँ अलग लेबल
- Design: Black / Dark Navy / Electric Blue, Poppins

## Phases
1 Home + Navigation (यह कोड)   2 Video Import + Preview   3 Timeline
4 Trim/Split/Merge   5 Text + Audio   6 Photo + GIF   7 Effects + Filters
8 Export Engine   9 AI Studio   10 Pro features + Plugins

## ईमानदार नोट
Motion/Camera tracking, Optical flow, Mask tracking, AI Video Generator ₹0 बजट में अभी मुश्किल हैं।
ये "जल्द" दिखेंगे, काम करते हुए नहीं दिखाए जाएँगे।

## Phase 1 में क्या काम करता है
- होम डैशबोर्ड, 15 विकल्प, Recent Projects
- नया प्रोजेक्ट बनाना, My Projects (सेव रहता है, हटा सकते हो)
- Beginner / Pro मोड (सेव रहता है)
- Android बैक बटन
- बाकी सब स्क्रीन पर साफ़ लिखा है कि वह किस Phase में बनेगा

## फ़ाइलें कहाँ रखनी हैं
maxo-edit/ (create-expo-app से बना फ़ोल्डर)
  App.tsx            <- पुरानी App.tsx की जगह
  src/theme.ts, src/features.ts, src/store.tsx
  src/screens/HomeScreen.tsx, WorkspaceScreen.tsx, ProjectsScreen.tsx, SettingsScreen.tsx

## सेटअप (टर्मिनल में)
npx create-expo-app@latest maxo-edit --template blank-typescript
cd maxo-edit
npx expo install @react-native-async-storage/async-storage expo-font @expo-google-fonts/poppins
(फिर ऊपर की फ़ाइलें रखो)
npx expo start --tunnel
फ़ोन में Expo Go खोलकर QR स्कैन करो।
