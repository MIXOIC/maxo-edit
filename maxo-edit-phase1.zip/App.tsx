import React, { useEffect, useState } from 'react';
import { BackHandler, SafeAreaView, StatusBar, View, ActivityIndicator } from 'react-native';
import { useFonts, Poppins_400Regular, Poppins_500Medium, Poppins_700Bold } from '@expo-google-fonts/poppins';
import { StoreProvider, useStore } from './src/store';
import { FEATURES, Feature } from './src/features';
import { C } from './src/theme';
import HomeScreen from './src/screens/HomeScreen';
import WorkspaceScreen from './src/screens/WorkspaceScreen';
import ProjectsScreen from './src/screens/ProjectsScreen';
import SettingsScreen from './src/screens/SettingsScreen';

type Route = { name: 'home' } | { name: 'projects' } | { name: 'settings' } | { name: 'feature'; feature: Feature };

function Shell() {
  const [route, setRoute] = useState<Route>({ name: 'home' });
  const { addProject } = useStore();
  const home = () => setRoute({ name: 'home' });

  useEffect(() => {
    const sub = BackHandler.addEventListener('hardwareBackPress', () => {
      if (route.name === 'home') return false;
      home();
      return true;
    });
    return () => sub.remove();
  }, [route]);

  const open = (f: Feature) => {
    if (f.id === 'new_project') { addProject(); setRoute({ name: 'projects' }); }
    else if (f.id === 'projects') setRoute({ name: 'projects' });
    else if (f.id === 'settings') setRoute({ name: 'settings' });
    else setRoute({ name: 'feature', feature: f });
  };

  if (route.name === 'projects') return <ProjectsScreen onBack={home} />;
  if (route.name === 'settings') return <SettingsScreen onBack={home} />;
  if (route.name === 'feature') return <WorkspaceScreen feature={route.feature} onBack={home} />;
  return <HomeScreen onOpen={open} />;
}

export default function App() {
  const [loaded] = useFonts({ Poppins_400Regular, Poppins_500Medium, Poppins_700Bold });
  if (!loaded) return <View style={{ flex: 1, backgroundColor: C.bg, justifyContent: 'center' }}><ActivityIndicator color={C.blue} /></View>;
  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: C.bg }}>
      <StatusBar barStyle="light-content" backgroundColor={C.bg} />
      <StoreProvider><Shell /></StoreProvider>
    </SafeAreaView>
  );
}
