import React, { createContext, useContext, useEffect, useState } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';

export type Mode = 'beginner' | 'pro';
export type Project = { id: string; name: string; createdAt: number; updatedAt: number };
type Ctx = {
  mode: Mode; setMode: (m: Mode) => void;
  projects: Project[]; addProject: () => void; removeProject: (id: string) => void;
};
const K_MODE = 'maxo:mode', K_PROJ = 'maxo:projects';
const Store = createContext<Ctx>(null as unknown as Ctx);
export const useStore = () => useContext(Store);

export function StoreProvider({ children }: { children: React.ReactNode }) {
  const [mode, setModeState] = useState<Mode>('beginner');
  const [projects, setProjects] = useState<Project[]>([]);

  useEffect(() => {
    (async () => {
      try {
        const m = await AsyncStorage.getItem(K_MODE);
        if (m === 'pro' || m === 'beginner') setModeState(m);
        const p = await AsyncStorage.getItem(K_PROJ);
        if (p) setProjects(JSON.parse(p));
      } catch (e) { console.warn('लोड नहीं हो पाया', e); }
    })();
  }, []);

  const saveProjects = (list: Project[]) => {
    setProjects(list);
    AsyncStorage.setItem(K_PROJ, JSON.stringify(list)).catch((e) => console.warn('सेव नहीं हो पाया', e));
  };
  const setMode = (m: Mode) => {
    setModeState(m);
    AsyncStorage.setItem(K_MODE, m).catch((e) => console.warn(e));
  };
  const addProject = () => {
    const now = Date.now();
    saveProjects([{ id: String(now), name: 'Project ' + (projects.length + 1), createdAt: now, updatedAt: now }, ...projects]);
  };
  const removeProject = (id: string) => saveProjects(projects.filter((p) => p.id !== id));

  return <Store.Provider value={{ mode, setMode, projects, addProject, removeProject }}>{children}</Store.Provider>;
}
