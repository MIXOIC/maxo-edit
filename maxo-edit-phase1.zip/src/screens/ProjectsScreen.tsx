import React from 'react';
import { View, Text, Pressable, FlatList, StyleSheet } from 'react-native';
import { C, F } from '../theme';
import { useStore } from '../store';

export default function ProjectsScreen({ onBack }: { onBack: () => void }) {
  const { projects, addProject, removeProject } = useStore();
  return (
    <View style={s.root}>
      <Pressable onPress={onBack} style={s.back}><Text style={s.backT}>← वापस</Text></Pressable>
      <Text style={s.title}>My Projects</Text>
      <Pressable onPress={addProject} style={s.add}><Text style={s.addT}>➕  नया प्रोजेक्ट</Text></Pressable>
      <FlatList
        data={projects}
        keyExtractor={(p) => p.id}
        ListEmptyComponent={<Text style={s.empty}>अभी कोई प्रोजेक्ट नहीं। ऊपर से बनाओ।</Text>}
        renderItem={({ item }) => (
          <View style={s.row}>
            <View style={{ flex: 1 }}>
              <Text style={s.name}>{item.name}</Text>
              <Text style={s.date}>{new Date(item.createdAt).toLocaleString()}</Text>
            </View>
            <Pressable onPress={() => removeProject(item.id)} accessibilityLabel="प्रोजेक्ट हटाओ"><Text style={s.del}>हटाओ</Text></Pressable>
          </View>
        )}
      />
    </View>
  );
}

const s = StyleSheet.create({
  root: { flex: 1, backgroundColor: C.bg, padding: 16 },
  back: { paddingVertical: 8 },
  backT: { color: C.blue, fontFamily: F.med, fontSize: 16 },
  title: { color: C.text, fontFamily: F.bold, fontSize: 24, marginVertical: 8 },
  add: { backgroundColor: C.blue, borderRadius: 14, padding: 14, alignItems: 'center', marginBottom: 14 },
  addT: { color: '#fff', fontFamily: F.bold },
  empty: { color: C.mute, fontFamily: F.reg, marginTop: 10 },
  row: { flexDirection: 'row', alignItems: 'center', backgroundColor: C.card, borderRadius: 14, padding: 14, marginBottom: 10, borderColor: C.line, borderWidth: 1 },
  name: { color: C.text, fontFamily: F.med, fontSize: 16 },
  date: { color: C.mute, fontFamily: F.reg, fontSize: 12 },
  del: { color: '#FF6B6B', fontFamily: F.med },
});
