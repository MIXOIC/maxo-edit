import React from 'react';
import { View, Text, Pressable, ScrollView, StyleSheet, useWindowDimensions } from 'react-native';
import { C, F } from '../theme';
import { FEATURES, Feature } from '../features';
import { useStore } from '../store';

export default function HomeScreen({ onOpen }: { onOpen: (f: Feature) => void }) {
  const { mode, projects } = useStore();
  const { width } = useWindowDimensions();
  const tile = (width - 16 * 2 - 10 * 2) / 3;
  const newProject = FEATURES[0];

  return (
    <ScrollView style={s.root} contentContainerStyle={{ padding: 16, paddingBottom: 40 }}>
      <View style={s.head}>
        <View>
          <Text style={s.logo}>MAXO EDIT</Text>
          <Text style={s.tag}>Create Beyond Limits.</Text>
        </View>
        <View style={s.pill}><Text style={s.pillT}>{mode === 'pro' ? 'Pro Mode' : 'Beginner Mode'}</Text></View>
      </View>

      <Pressable style={s.quick} onPress={() => onOpen(newProject)} accessibilityRole="button">
        <Text style={s.quickT}>➕  नया प्रोजेक्ट शुरू करो</Text>
      </Pressable>

      <Text style={s.h2}>Recent Projects</Text>
      {projects.length === 0 ? (
        <Text style={s.empty}>अभी कोई प्रोजेक्ट नहीं है। ऊपर के बटन से पहला बनाओ।</Text>
      ) : (
        <ScrollView horizontal showsHorizontalScrollIndicator={false}>
          {projects.slice(0, 6).map((p) => (
            <View key={p.id} style={s.proj}>
              <Text style={s.projIcon}>🎞️</Text>
              <Text style={s.projName} numberOfLines={1}>{p.name}</Text>
              <Text style={s.projDate}>{new Date(p.updatedAt).toLocaleDateString()}</Text>
            </View>
          ))}
        </ScrollView>
      )}

      <Text style={s.h2}>Studio</Text>
      <View style={s.grid}>
        {FEATURES.map((f) => (
          <Pressable key={f.id} style={[s.tile, { width: tile }]} onPress={() => onOpen(f)} accessibilityRole="button" accessibilityLabel={f.title}>
            <Text style={s.tileIcon}>{f.icon}</Text>
            <Text style={s.tileT} numberOfLines={2}>{f.title}</Text>
            {f.status === 'soon' && <Text style={s.soon}>जल्द</Text>}
          </Pressable>
        ))}
      </View>
    </ScrollView>
  );
}

const s = StyleSheet.create({
  root: { flex: 1, backgroundColor: C.bg },
  head: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 },
  logo: { color: C.text, fontFamily: F.bold, fontSize: 26, letterSpacing: 1 },
  tag: { color: C.blue, fontFamily: F.med, fontSize: 13 },
  pill: { borderColor: C.line, borderWidth: 1, borderRadius: 99, paddingHorizontal: 12, paddingVertical: 5 },
  pillT: { color: C.mute, fontFamily: F.med, fontSize: 12 },
  quick: { backgroundColor: C.blue, borderRadius: 16, padding: 18, alignItems: 'center' },
  quickT: { color: '#fff', fontFamily: F.bold, fontSize: 17 },
  h2: { color: C.text, fontFamily: F.bold, fontSize: 17, marginTop: 24, marginBottom: 10 },
  empty: { color: C.mute, fontFamily: F.reg },
  proj: { backgroundColor: C.card, borderRadius: 14, padding: 12, marginRight: 10, width: 130, borderColor: C.line, borderWidth: 1 },
  projIcon: { fontSize: 26 },
  projName: { color: C.text, fontFamily: F.med, marginTop: 6 },
  projDate: { color: C.mute, fontFamily: F.reg, fontSize: 12 },
  grid: { flexDirection: 'row', flexWrap: 'wrap', gap: 10 },
  tile: { backgroundColor: C.card, borderRadius: 16, padding: 10, minHeight: 100, borderColor: C.line, borderWidth: 1, alignItems: 'center', justifyContent: 'center' },
  tileIcon: { fontSize: 26, marginBottom: 6 },
  tileT: { color: C.text, fontFamily: F.med, fontSize: 12, textAlign: 'center' },
  soon: { color: C.warn, fontFamily: F.reg, fontSize: 10, marginTop: 3 },
});
