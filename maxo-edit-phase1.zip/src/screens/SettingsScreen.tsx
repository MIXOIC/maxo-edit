import React from 'react';
import { View, Text, Pressable, StyleSheet } from 'react-native';
import { C, F } from '../theme';
import { useStore, Mode } from '../store';

const MODES: { id: Mode; title: string; desc: string }[] = [
  { id: 'beginner', title: 'Beginner Mode', desc: 'आसान इंटरफ़ेस, सरल टूल, गाइडेड निर्देश, बेसिक टाइमलाइन' },
  { id: 'pro', title: 'Pro Editor Mode', desc: 'एडवांस टाइमलाइन, मल्टी-लेयर, कीफ़्रेम, एडवांस एक्सपोर्ट' },
];

export default function SettingsScreen({ onBack }: { onBack: () => void }) {
  const { mode, setMode } = useStore();
  return (
    <View style={s.root}>
      <Pressable onPress={onBack} style={s.back}><Text style={s.backT}>← वापस</Text></Pressable>
      <Text style={s.title}>Settings</Text>
      {MODES.map((m) => (
        <Pressable key={m.id} onPress={() => setMode(m.id)} style={[s.card, mode === m.id && s.sel]} accessibilityRole="radio" accessibilityState={{ selected: mode === m.id }}>
          <Text style={s.name}>{m.title}{mode === m.id ? '  ✓' : ''}</Text>
          <Text style={s.desc}>{m.desc}</Text>
        </Pressable>
      ))}
      <Text style={s.note}>मोड कभी भी बदल सकते हो। टाइमलाइन बनने पर यह फ़र्क़ वहाँ दिखेगा।</Text>
    </View>
  );
}

const s = StyleSheet.create({
  root: { flex: 1, backgroundColor: C.bg, padding: 16 },
  back: { paddingVertical: 8 },
  backT: { color: C.blue, fontFamily: F.med, fontSize: 16 },
  title: { color: C.text, fontFamily: F.bold, fontSize: 24, marginVertical: 8 },
  card: { backgroundColor: C.card, borderRadius: 16, padding: 16, marginBottom: 12, borderColor: C.line, borderWidth: 1 },
  sel: { borderColor: C.blue },
  name: { color: C.text, fontFamily: F.bold, fontSize: 16 },
  desc: { color: C.mute, fontFamily: F.reg, marginTop: 4 },
  note: { color: C.mute, fontFamily: F.reg, fontSize: 13, marginTop: 6 },
});
