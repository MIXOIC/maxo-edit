import React from 'react';
import { View, Text, Pressable, StyleSheet } from 'react-native';
import { C, F } from '../theme';
import { Feature } from '../features';

// अभी जो फ़ीचर नहीं बने, उनके लिए साफ़ और ईमानदार स्क्रीन।
export default function WorkspaceScreen({ feature, onBack }: { feature: Feature; onBack: () => void }) {
  return (
    <View style={s.root}>
      <Pressable onPress={onBack} style={s.back} accessibilityRole="button"><Text style={s.backT}>← वापस</Text></Pressable>
      <View style={s.body}>
        <Text style={s.icon}>{feature.icon}</Text>
        <Text style={s.title}>{feature.title}</Text>
        <Text style={s.desc}>{feature.desc}</Text>
        <View style={s.badge}>
          <Text style={s.badgeT}>अभी काम नहीं करता। यह Phase {feature.phase} में बनेगा।</Text>
        </View>
      </View>
    </View>
  );
}

const s = StyleSheet.create({
  root: { flex: 1, backgroundColor: C.bg, padding: 16 },
  back: { paddingVertical: 8 },
  backT: { color: C.blue, fontFamily: F.med, fontSize: 16 },
  body: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  icon: { fontSize: 56 },
  title: { color: C.text, fontFamily: F.bold, fontSize: 24, marginTop: 10 },
  desc: { color: C.mute, fontFamily: F.reg, marginTop: 6, textAlign: 'center' },
  badge: { marginTop: 20, borderColor: C.warn, borderWidth: 1, borderRadius: 12, padding: 12 },
  badgeT: { color: C.warn, fontFamily: F.med, textAlign: 'center' },
});
