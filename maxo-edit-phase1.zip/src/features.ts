// status: 'ready' = आज काम करता है, 'soon' = अभी नहीं बना (साफ़ बताया जाएगा)
export type Feature = { id: string; title: string; icon: string; phase: number; status: 'ready' | 'soon'; desc: string };

export const FEATURES: Feature[] = [
  { id: 'new_project', title: 'New Project', icon: '➕', phase: 1, status: 'ready', desc: 'नया एडिटिंग प्रोजेक्ट' },
  { id: 'new_video', title: 'New Video', icon: '🎬', phase: 2, status: 'soon', desc: 'वीडियो इम्पोर्ट, प्रीव्यू और टाइमलाइन' },
  { id: 'photo', title: 'Photo Editing', icon: '🖼️', phase: 6, status: 'soon', desc: 'क्रॉप, फ़िल्टर, बैकग्राउंड, कोलाज' },
  { id: 'audio', title: 'Audio Studio', icon: '🎙️', phase: 5, status: 'soon', desc: 'रिकॉर्डिंग, ट्रिम, मिक्सिंग, EQ' },
  { id: 'gif', title: 'GIF Maker', icon: '🌀', phase: 6, status: 'soon', desc: 'वीडियो या फ़ोटो से GIF' },
  { id: 'ai', title: 'AI Studio', icon: '✨', phase: 9, status: 'soon', desc: 'कैप्शन, आवाज़, बैकग्राउंड रिमूवर' },
  { id: 'templates', title: 'Templates', icon: '🧩', phase: 10, status: 'soon', desc: 'टेम्पलेट और प्रीसेट लाइब्रेरी' },
  { id: 'effects', title: 'Effects & Filters', icon: '🎨', phase: 7, status: 'soon', desc: 'इफ़ेक्ट, फ़िल्टर, कलर करेक्शन' },
  { id: 'captions', title: 'Auto Captions', icon: '💬', phase: 9, status: 'soon', desc: 'अपने आप सबटाइटल' },
  { id: 'import', title: 'Import Hub', icon: '📥', phase: 2, status: 'soon', desc: 'फ़ाइलें और ZIP पैकेज इम्पोर्ट' },
  { id: 'export', title: 'Export Studio', icon: '📤', phase: 8, status: 'soon', desc: 'MP4/WebM, 720p/1080p, क्वालिटी' },
  { id: 'assets', title: 'Asset Manager', icon: '🗂️', phase: 10, status: 'soon', desc: 'फ़ॉन्ट, LUT, स्टिकर मैनेज करें' },
  { id: 'plugins', title: 'Plugin Center', icon: '🔌', phase: 10, status: 'soon', desc: 'नए टूल जोड़ें और मैनेज करें' },
  { id: 'projects', title: 'My Projects', icon: '📁', phase: 1, status: 'ready', desc: 'तुम्हारे सेव किए प्रोजेक्ट' },
  { id: 'settings', title: 'Settings', icon: '⚙️', phase: 1, status: 'ready', desc: 'Beginner / Pro मोड' },
];
