export const C = {
  bg: '#05070F', navy: '#0B1226', card: '#111A33', line: '#1E2A4D',
  blue: '#2F6BFF', text: '#F2F5FF', mute: '#8A95B8', warn: '#FFB84D', ok: '#35D399',
};
export const F = { reg: 'Poppins_400Regular', med: 'Poppins_500Medium', bold: 'Poppins_700Bold' };
